import {
    test,
    expect,
    type Page,
    type Locator,
    type TestInfo
} from '@playwright/test';
import fs from 'node:fs';
import path from 'node:path';

const HOME = 'https://didongviet.vn/';
const CATALOG = 'https://didongviet.vn/dien-thoai.html';
const IPHONE = 'https://didongviet.vn/dien-thoai-iphone.html';

const RUN_ID =
    process.env.ASM09_RUN_ID ||
    new Date().toISOString().replace(/[:.]/g, '-');

const ROOT =
    process.env.ASM09_REPORT_ROOT ||
    path.resolve(
        process.cwd(),
        '..',
        'Test Report - Group08',
        '23130067_PhamMinhDuc_ASM09',
        'V2'
    );

const RUN_DIR = path.join(ROOT, 'runs', RUN_ID);
const EVIDENCE_DIR = path.join(RUN_DIR, 'evidence');

fs.mkdirSync(EVIDENCE_DIR, { recursive: true });

test.use({
    viewport: { width: 1440, height: 900 },
    actionTimeout: 12000,
    navigationTimeout: 45000,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure'
});

type Status =
    | 'PASS'
    | 'DEFECT_CANDIDATE'
    | 'INCONCLUSIVE'
    | 'SCRIPT_OR_ENV_ERROR';

type Card = {
    name: string;
    url: string;
    slug: string;
    price: number | null;
};

type CompareItem = {
    productId: string;
    slug: string;
    name: string;
    price: number | null;
};

type Evidence = {
    id: string;
    title: string;
    status: Status;
    startedAt: string;
    finishedAt?: string;
    url?: string;
    reason?: string;
    observations: unknown[];
    technicalErrors: unknown[];
};

class SuspectedDefect extends Error {
    constructor(
        message: string,
        public details: unknown
    ) {
        super(message);
        this.name = 'SuspectedDefect';
    }
}

class NotVerifiable extends Error {
    constructor(message: string) {
        super(message);
        this.name = 'NotVerifiable';
    }
}

function note(e: Evidence, value: unknown) {
    e.observations.push(value);
    console.log('[OBSERVATION]', JSON.stringify(value));
}

function candidate(
    condition: boolean,
    message: string,
    details: unknown = {}
) {
    if (condition) {
        throw new SuspectedDefect(message, details);
    }
}

function unknown(message: string): never {
    throw new NotVerifiable(message);
}

function normalize(s: string) {
    return s.replace(/\s+/g, ' ').trim();
}

function saveResult(e: Evidence) {
    const file = path.join(RUN_DIR, 'results.json');

    let rows: Evidence[] = [];

    if (fs.existsSync(file)) {
        try {
            rows = JSON.parse(fs.readFileSync(file, 'utf8'));
        } catch {
            rows = [];
        }
    }

    rows = rows.filter(x => x.id !== e.id);
    rows.push(e);
    rows.sort((a, b) => a.id.localeCompare(b.id));

    fs.writeFileSync(
        file,
        JSON.stringify(rows, null, 2),
        'utf8'
    );

    const escapeCSV = (value: unknown) =>
        `"${String(value ?? '').replace(/"/g, '""')}"`;

    const csv = [
        ['ID', 'Title', 'Status', 'Reason', 'URL']
            .map(escapeCSV).join(','),
        ...rows.map(x =>
            [x.id, x.title, x.status, x.reason, x.url]
                .map(escapeCSV).join(',')
        )
    ];

    fs.writeFileSync(
        path.join(RUN_DIR, 'results.csv'),
        '\uFEFF' + csv.join('\n'),
        'utf8'
    );
}

function register(
    feature: 'F01' | 'F02' | 'F03',
    number: number,
    title: string,
    action: (page: Page, e: Evidence) => Promise<void>
) {
    const id =
        `ASM09_DUC_${feature}_${String(number).padStart(3, '0')}`;

    test(`${id} - ${title}`, async ({ page }, info: TestInfo) => {
        const e: Evidence = {
            id,
            title,
            status: 'INCONCLUSIVE',
            startedAt: new Date().toISOString(),
            observations: [],
            technicalErrors: []
        };

        page.on('pageerror', error => {
            e.technicalErrors.push({
                kind: 'JS_ERROR',
                message: error.message
            });
        });

        page.on('response', response => {
            if (
                response.url().includes('didongviet.vn') &&
                response.status() >= 500
            ) {
                e.technicalErrors.push({
                    kind: 'HTTP_ERROR',
                    status: response.status(),
                    url: response.url()
                });
            }
        });

        let failure: unknown = null;

        try {
            await action(page, e);
            e.status = 'PASS';
        } catch (error) {
            failure = error;
            e.reason = String(error);

            if (error instanceof SuspectedDefect) {
                e.status = 'DEFECT_CANDIDATE';
                note(e, error.details);
            } else if (error instanceof NotVerifiable) {
                e.status = 'INCONCLUSIVE';
            } else {
                e.status = 'SCRIPT_OR_ENV_ERROR';
            }
        } finally {
            e.finishedAt = new Date().toISOString();
            e.url = page.url();

            const stamp = Date.now();
            const name = `${id}-${stamp}`;

            const jsonPath = path.join(
                EVIDENCE_DIR,
                `${name}.json`
            );

            const imagePath = path.join(
                EVIDENCE_DIR,
                `${name}.png`
            );

            try {
                await page.screenshot({
                    path: imagePath,
                    fullPage: false,
                    timeout: 10000
                });

                await info.attach('screenshot', {
                    path: imagePath,
                    contentType: 'image/png'
                });
            } catch (error) {
                note(e, { screenshotError: String(error) });
            }

            fs.writeFileSync(
                jsonPath,
                JSON.stringify(e, null, 2),
                'utf8'
            );

            try {
                await info.attach('evidence', {
                    path: jsonPath,
                    contentType: 'application/json'
                });
            } catch {
                // The JSON evidence has already been saved.
            }

            saveResult(e);

            console.log(
                `[ASM09] ${id}: ${e.status}`
            );
        }

        if (failure instanceof NotVerifiable) {
            test.skip(true, failure.message);
        }

        if (failure) {
            throw failure;
        }
    });
}

// ======================================================
// COMMON PAGE HELPERS
// ======================================================

async function navigate(page: Page, url: string) {
    const response = await page.goto(url, {
        waitUntil: 'domcontentloaded'
    });

    if (!response) {
        unknown('Navigation returned no HTTP response');
    }

    if ([403, 429].includes(response.status())) {
        unknown(`Access limited: HTTP ${response.status()}`);
    }

    candidate(
        response.status() >= 500,
        'Main page returned a server error',
        { url, status: response.status() }
    );

    if (response.status() >= 400) {
        unknown(`Page unavailable: HTTP ${response.status()}`);
    }

    await expect(page.locator('body')).toBeVisible();
}

async function waitForCards(page: Page) {
    try {
        await expect(
            page.getByText('So sánh', { exact: true }).first()
        ).toBeVisible({ timeout: 18000 });
    } catch {
        unknown('Product comparison controls were not loaded');
    }

    await page.waitForTimeout(650);
}

function searchField(page: Page) {
    return page.locator(
        'input[placeholder*="Bạn muốn mua gì"]:visible,' +
        'input[placeholder*="Nhập tên sản phẩm"]:visible'
    ).last();
}

async function dismissCookie(page: Page) {
    const buttons = page.getByRole('button', {
        name: /đồng ý|chấp nhận|đã hiểu|accept/i
    });

    if (await buttons.first().isVisible().catch(() => false)) {
        await buttons.first().click().catch(() => {});
    }
}

async function search(
    page: Page,
    word: string,
    e: Evidence
) {
    await navigate(page, HOME);
    await dismissCookie(page);

    const input = searchField(page);

    if (!(await input.isVisible().catch(() => false))) {
        unknown('Search field not found');
    }

    await input.fill(word);

    const before = page.url();
    await input.press('Enter');

    try {
        await page.waitForURL(
            url => url.toString() !== before,
            { timeout: 15000 }
        );
    } catch {
        unknown(`Search did not navigate: ${word}`);
    }

    const url = new URL(page.url());

    try {
        if (url.pathname === '/search') {
            await expect.poll(async () => {
                const body = await page.locator('body').innerText();

                return (
                    /Tìm thấy\s+\d+\s+sản phẩm/i.test(body) ||
                    /Không tìm thấy kết quả/i.test(body)
                );
            }, { timeout: 20000 }).toBe(true);
        } else {
            await waitForCards(page);
        }
    } catch {
        unknown('Search result did not finish loading');
    }

    const body = await page.locator('body').innerText();
    const countMatch = body.match(
        /Tìm thấy\s+(\d+)\s+sản phẩm/i
    );

    const result = {
        keyword: word,
        url: page.url(),
        count: countMatch ? Number(countMatch[1]) : null,
        noResults: /Không tìm thấy kết quả/i.test(body),
        body
    };

    note(e, {
        keyword: word,
        url: result.url,
        count: result.count,
        noResults: result.noResults,
        excerpt: body.slice(0, 600)
    });

    candidate(
        /Internal server error|Application error|Cannot GET/i
            .test(body),
        'Search caused application/server error',
        { word, url: result.url }
    );

    return result;
}

// ======================================================
// PRODUCT CARD EXTRACTION
// ======================================================

function compareControls(page: Page) {
    return page.getByText('So sánh', {
        exact: true
    });
}

async function cardFromButton(
    button: Locator
): Promise<Card | null> {
    return button.evaluate(element => {
        let parent = element.parentElement as HTMLElement | null;

        for (let depth = 0; parent && depth < 9; depth++) {
            const links = Array.from(
                parent.querySelectorAll('a[href]')
            ) as HTMLAnchorElement[];

            const valid = links.filter(link => {
                try {
                    const url = new URL(link.href);

                    return /^\/dien-thoai\/[^/]+\.html$/i
                        .test(url.pathname);
                } catch {
                    return false;
                }
            });

            const urls = [...new Set(valid.map(x => x.href))];

            if (urls.length === 1 && valid.length) {
                const url = urls[0];
                const text = parent.innerText || '';

                const priceMatch = text.match(
                    /\d{1,3}(?:[.,]\d{3})+\s*(?:đ|₫)/i
                );

                const price = priceMatch
                    ? Number(priceMatch[0].replace(/\D/g, ''))
                    : null;

                const rawName = valid
                    .map(x => (x.innerText || x.textContent || '').trim())
                    .sort((a, b) => a.length - b.length)[0] || '';

                const name = rawName
                    .replace(/\s+/g, ' ')
                    .slice(0, 150);

                const slug = new URL(url)
                    .pathname.split('/').pop()!
                    .replace(/\.html$/i, '');

                return {
                    name,
                    url,
                    slug,
                    price
                };
            }

            if (urls.length > 1) {
                return null;
            }

            parent = parent.parentElement;
        }

        return null;
    });
}

async function cards(
    page: Page,
    max = 20
): Promise<Card[]> {
    const locators = compareControls(page);
    const count = Math.min(await locators.count(), max + 8);

    const result: Card[] = [];
    const seen = new Set<string>();

    for (let i = 0; i < count; i++) {
        const button = locators.nth(i);

        if (!(await button.isVisible().catch(() => false))) {
            continue;
        }

        const item = await cardFromButton(button)
            .catch(() => null);

        if (!item || seen.has(item.slug)) continue;

        seen.add(item.slug);
        result.push(item);

        if (result.length >= max) break;
    }

    return result;
}

async function availableCards(page: Page) {
    await waitForCards(page);

    const result = await cards(page);

    if (result.length === 0) {
        unknown('Unable to extract product cards');
    }

    return result;
}

function cardSignature(items: Card[]) {
    return items.map(x => x.slug).join('|');
}

function findPriceErrors(
    items: Card[],
    min: number,
    max: number
) {
    return items.filter(
        item =>
            item.price !== null &&
            (item.price < min || item.price > max)
    );
}

function findSortErrors(
    items: Card[],
    direction: 'ASC' | 'DESC'
) {
    const priced = items.filter(
        item => item.price !== null
    );

    const invalid: Array<{
        first: Card;
        second: Card;
    }> = [];

    for (let i = 1; i < priced.length; i++) {
        const a = priced[i - 1];
        const b = priced[i];

        if (
            (direction === 'ASC' && a.price! > b.price!) ||
            (direction === 'DESC' && a.price! < b.price!)
        ) {
            invalid.push({ first: a, second: b });
        }
    }

    return invalid;
}

async function verifyPrices(
    page: Page,
    e: Evidence,
    min: number,
    max: number
) {
    let observed: Card[] = [];
    let invalid: Card[] = [];

    for (let attempt = 0; attempt < 3; attempt++) {
        await page.waitForTimeout(750);

        observed = await cards(page);
        invalid = findPriceErrors(observed, min, max);

        if (observed.length >= 3 && invalid.length === 0) {
            break;
        }
    }

    if (observed.length === 0) {
        unknown('No product cards available for price validation');
    }

    const priced = observed.filter(x => x.price !== null);

    if (priced.length < 2) {
        unknown('Insufficient priced products');
    }

    note(e, {
        check: 'PRICE_RANGE',
        min,
        max,
        products: priced,
        invalid
    });

    candidate(
        invalid.length > 0,
        'Products outside selected price range',
        { min, max, invalid }
    );
}

async function verifySort(
    page: Page,
    e: Evidence,
    direction: 'ASC' | 'DESC'
) {
    let result: Card[] = [];
    let invalid: ReturnType<typeof findSortErrors> = [];

    for (let attempt = 0; attempt < 4; attempt++) {
        await page.waitForTimeout(700);
        result = await cards(page);
        invalid = findSortErrors(result, direction);

        if (result.length >= 5 && invalid.length === 0) {
            break;
        }
    }

    if (result.length < 3) {
        unknown('Insufficient products for sorting validation');
    }

    note(e, {
        check: 'PRICE_SORT',
        direction,
        prices: result.map(x => x.price),
        invalid
    });

    candidate(
        invalid.length > 0,
        `Incorrect ${direction} price order`,
        { direction, invalid }
    );
}

async function clickSort(
    page: Page,
    direction: 'ASC' | 'DESC'
) {
    const label = direction === 'ASC'
        ? 'Giá tăng dần'
        : 'Giá giảm dần';

    const text = page.getByText(label, {
        exact: true
    }).first();

    if (!(await text.isVisible().catch(() => false))) {
        unknown(`Sort control unavailable: ${label}`);
    }

    const button = text.locator(
        'xpath=ancestor-or-self::button[1]'
    );

    if (await button.count()) {
        await button.click();
    } else {
        await text.click();
    }

    await page.waitForTimeout(900);
}

// ======================================================
// FILTER / PRODUCT SPEC HELPERS
// ======================================================

function filteredUrl(options: {
    low?: number;
    high?: number;
    sort?: 'ASC' | 'DESC';
    ram?: number;
    storage?: number;
}) {
    const url = new URL(CATALOG);

    if (
        options.low !== undefined &&
        options.high !== undefined
    ) {
        url.searchParams.set(
            'gia',
            `${options.low},${options.high}`
        );
    }

    if (options.sort) {
        url.searchParams.set(
            'sort',
            options.sort === 'ASC'
                ? 'price_asc'
                : 'price_desc'
        );
    }

    if (options.ram) {
        url.searchParams.set(
            'spec_ram',
            `${options.ram}_gb`
        );
    }

    if (options.storage) {
        url.searchParams.set(
            'spec_bo_nho_trong',
            `${options.storage}_gb`
        );
    }

    return url.toString();
}

async function openFilter(
    page: Page,
    options: Parameters<typeof filteredUrl>[0]
) {
    await navigate(page, filteredUrl(options));
    await waitForCards(page);
}

async function readProductSpec(
    page: Page,
    product: Card,
    kind: 'RAM' | 'STORAGE'
): Promise<number | null> {
    const detail = await page.context().newPage();

    try {
        await navigate(detail, product.url);

        const text = await detail.locator('body').innerText();

        const patterns = kind === 'RAM'
            ? [
                /(?:^|\n)\s*(?:RAM|Dung lượng RAM)\s*[:：]?\s*\n?\s*(\d+)\s*GB/gi
            ]
            : [
                /(?:^|\n)\s*(?:Bộ nhớ trong|Dung lượng lưu trữ|ROM)\s*[:：]?\s*\n?\s*(\d+)\s*GB/gi,
                /(?:^|\n)\s*(?:Bộ nhớ trong|Dung lượng lưu trữ|ROM)\s*[:：]?\s*\n?\s*(\d+)\s*TB/gi
            ];

        const values: number[] = [];

        for (let i = 0; i < patterns.length; i++) {
            for (const match of text.matchAll(patterns[i])) {
                let value = Number(match[1]);

                if (kind === 'STORAGE' && i === 1) {
                    value *= 1024;
                }

                if (Number.isFinite(value)) {
                    values.push(value);
                }
            }
        }

        const unique = [...new Set(values)];

        // Multiple contradictory values might refer to
        // variants or recommendation sections.
        // Do not invent a defect from ambiguous text.
        return unique.length === 1 ? unique[0] : null;
    } finally {
        await detail.close().catch(() => {});
    }
}

async function verifyFacet(
    page: Page,
    e: Evidence,
    kind: 'RAM' | 'STORAGE',
    expected: number
) {
    const products = await availableCards(page);
    const sample = products.slice(0, 3);

    const checked: Array<{
        product: Card;
        actual: number | null;
    }> = [];

    for (const product of sample) {
        const actual = await readProductSpec(
            page,
            product,
            kind
        );

        checked.push({ product, actual });
    }

    const verified = checked.filter(
        x => x.actual !== null
    );

    note(e, {
        check: 'PRODUCT_DETAIL_SPEC',
        kind,
        expected,
        checked
    });

    if (verified.length === 0) {
        unknown(
            `Could not reliably extract ${kind} from product details`
        );
    }

    const invalid = verified.filter(
        x => x.actual !== expected
    );

    candidate(
        invalid.length > 0,
        `${kind} filter returned incompatible products`,
        { expected, invalid }
    );
}

// ======================================================
// COMPARISON HELPERS
// ======================================================

async function comparison(page: Page): Promise<CompareItem[]> {
    return page.evaluate(() => {
        const raw = localStorage.getItem('ddv-compare');

        if (!raw) return [];

        let parsed: any;

        try {
            parsed = JSON.parse(raw);
        } catch {
            throw new Error('Malformed comparison localStorage JSON');
        }

        const items = parsed?.state?.items;

        if (!Array.isArray(items)) return [];

        return items.filter(Boolean).map((item: any) => ({
            productId: String(item.productId ?? ''),
            slug: String(item.slug ?? ''),
            name: String(item.name ?? ''),
            price: typeof item.price === 'number'
                ? item.price
                : null
        }));
    });
}

async function waitCompare(
    page: Page,
    count: number
) {
    for (let i = 0; i < 16; i++) {
        const items = await comparison(page);

        if (items.length === count) {
            return items;
        }

        await page.waitForTimeout(250);
    }

    return comparison(page);
}

async function findCardButton(
    page: Page,
    slug: string
): Promise<Locator | null> {
    const buttons = compareControls(page);

    for (let i = 0; i < Math.min(await buttons.count(), 35); i++) {
        const button = buttons.nth(i);
        const product = await cardFromButton(button)
            .catch(() => null);

        if (product?.slug === slug) {
            return button;
        }
    }

    return null;
}

async function addProduct(
    page: Page,
    e: Evidence
): Promise<Card> {
    const before = await comparison(page);
    const products = await availableCards(page);

    const selected = new Set(before.map(x => x.slug));
    const target = products.find(
        x => !selected.has(x.slug)
    );

    if (!target) {
        unknown('No unselected comparison product');
    }

    const button = await findCardButton(page, target.slug);

    if (!button) {
        unknown('Compare button could not be matched to card');
    }

    await button.click();

    const after = await waitCompare(page, before.length + 1);

    note(e, {
        operation: 'ADD',
        target,
        before,
        after
    });

    candidate(
        after.length !== before.length + 1,
        'Comparison count failed to increase',
        { before, after, target }
    );

    candidate(
        !after.some(x => x.slug === target.slug),
        'Wrong product added to comparison',
        { target, after }
    );

    return target;
}

async function addProducts(
    page: Page,
    e: Evidence,
    count: number
) {
    await navigate(page, CATALOG);
    await waitForCards(page);

    const added: Card[] = [];

    for (let i = 0; i < count; i++) {
        added.push(await addProduct(page, e));
    }

    return added;
}

async function removeProduct(
    page: Page,
    e: Evidence,
    product: Card
) {
    const before = await comparison(page);
    const button = await findCardButton(
        page,
        product.slug
    );

    if (!button) {
        unknown('Selected product button unavailable');
    }

    await button.click();

    const after = await waitCompare(
        page,
        before.length - 1
    );

    note(e, {
        operation: 'REMOVE',
        product,
        before,
        after
    });

    candidate(
        after.some(x => x.slug === product.slug),
        'Removed product remains selected',
        { product, after }
    );

    candidate(
        after.length !== before.length - 1,
        'Removing a product changed the wrong count',
        { before, after }
    );

    return after;
}

function compareIds(items: CompareItem[]) {
    return items.map(x => x.productId).join('|');
}

function uniqueComparison(items: CompareItem[]) {
    const ids = items.map(x => x.productId);
    const slugs = items.map(x => x.slug);

    return (
        new Set(ids).size === ids.length &&
        new Set(slugs).size === slugs.length
    );
}

function validateStoredPrices(
    added: Card[],
    items: CompareItem[]
) {
    return added.flatMap(product => {
        const stored = items.find(
            x => x.slug === product.slug
        );

        if (!stored || product.price === null) return [];

        if (stored.price !== product.price) {
            return [{
                product,
                stored,
                expected: product.price,
                actual: stored.price
            }];
        }

        return [];
    });
}

async function openComparisonTable(page: Page) {
    const pattern =
        /so sánh ngay|xem so sánh|so sánh sản phẩm/i;

    const button = page.getByRole('button', {
        name: pattern
    }).first();

    const link = page.getByRole('link', {
        name: pattern
    }).first();

    if (await button.isVisible().catch(() => false)) {
        await button.click();
    } else if (await link.isVisible().catch(() => false)) {
        await link.click();
    } else {
        unknown('Comparison table entry point not identified');
    }

    await page.waitForTimeout(800);
}

// ======================================================
// 90 TEST CASES
// ======================================================

test.describe('ASM09 DUC - DEFECT HUNTING V2', () => {
    test.setTimeout(120000);

    // ====================================================
    // F01 - 30 SEARCH TESTS
    // ====================================================

    const knownKeywords = [
        ['iPhone', 'iphone'],
        ['Samsung', 'samsung'],
        ['Galaxy A07', 'galaxy a07'],
        ['OPPO', 'oppo'],
        ['Xiaomi', 'xiaomi'],
        ['REDMI', 'redmi'],
        ['iPhone 14', 'iphone 14'],
        ['Samsung Galaxy', 'samsung'],
        ['Galaxy A17', 'galaxy a17']
    ] as const;

    knownKeywords.forEach(([word, expected], index) => {
        register('F01', index + 1,
            `Search relevant products: ${word}`,
            async (page, e) => {
                const result = await search(page, word, e);
                const products = await cards(page);

                if (!products.length) {
                    unknown('Cannot inspect search product cards');
                }

                const matching = products.filter(x =>
                    x.name.toLowerCase().includes(expected)
                );

                note(e, {
                    expected,
                    inspected: products,
                    matchingCount: matching.length
                });

                candidate(
                    matching.length === 0,
                    'Search results appear unrelated to keyword',
                    { word, products }
                );
            }
        );
    });

    const caseVariants = [
        ['Samsung', 'samsung'],
        ['Samsung', 'SAMSUNG'],
        ['Samsung', 'SaMsUnG'],
        ['iPhone', 'iphone'],
        ['OPPO', 'oppo'],
        ['Galaxy A07', 'galaxy a07']
    ] as const;

    caseVariants.forEach(([base, variant], index) => {
        register('F01', index + 10,
            `Search case consistency: ${variant}`,
            async (page, e) => {
                await search(page, base, e);
                const before = await cards(page);

                await search(page, variant, e);
                const after = await cards(page);

                if (!before.length || !after.length) {
                    unknown('One keyword variant produced no inspectable cards');
                }

                const baseSlugs = new Set(before.map(x => x.slug));
                const common = after.filter(x =>
                    baseSlugs.has(x.slug)
                );

                note(e, {
                    base,
                    variant,
                    before: before.slice(0, 8),
                    after: after.slice(0, 8),
                    common: common.length
                });

                candidate(
                    common.length === 0,
                    'Capitalization changes all matching products',
                    { base, variant, before, after }
                );
            }
        );
    });

    const unusualKeywords = [
        'asm09_duc_no_product_999997',
        '<b>ASM09</b>',
        "Samsung'",
        'Samsung" OR "1"="1',
        '📱📱📱',
        'x'.repeat(512)
    ];

    unusualKeywords.forEach((word, index) => {
        register('F01', index + 16,
            `Unusual search input ${index + 1}`,
            async (page, e) => {
                const result = await search(page, word, e);

                note(e, {
                    length: word.length,
                    count: result.count,
                    noResults: result.noResults
                });

                candidate(
                    /Unhandled Runtime Error|Internal server error/i
                        .test(result.body),
                    'Unusual search input caused application failure',
                    { word, url: result.url }
                );
            }
        );
    });

    const spacingVariants = [
        ' Samsung',
        'Samsung ',
        'Samsung  Galaxy'
    ];

    spacingVariants.forEach((word, index) => {
        register('F01', index + 22,
            `Whitespace search: ${JSON.stringify(word)}`,
            async (page, e) => {
                const result = await search(page, word, e);

                note(e, {
                    word,
                    resultUrl: result.url,
                    count: result.count
                });

                // Normalization policy is not yet established.
                // Only document observed behavior.
            }
        );
    });

    register('F01', 25, 'HTML injection should remain text',
        async (page, e) => {
            await navigate(page, HOME);

            const payload =
                '<b id="asm09-duc-v2">PROBE</b>';

            const field = searchField(page);
            await field.fill(payload);

            const before = await page.locator(
                '#asm09-duc-v2'
            ).count();

            await field.press('Enter');
            await page.waitForTimeout(600);

            const after = await page.locator(
                '#asm09-duc-v2'
            ).count();

            note(e, { payload, before, after });

            candidate(
                before > 0 || after > 0,
                'Search input became executable/rendered HTML',
                { payload, before, after }
            );
        }
    );

    register('F01', 26, 'Search persists after reload',
        async (page, e) => {
            const result = await search(
                page,
                'Galaxy A07',
                e
            );

            await page.reload({
                waitUntil: 'domcontentloaded'
            });

            const after = page.url();

            note(e, { before: result.url, after });

            candidate(
                new URL(after).searchParams.get('q') !==
                new URL(result.url).searchParams.get('q'),
                'Search query changed after reload',
                { before: result.url, after }
            );
        }
    );

    register('F01', 27, 'Back navigation after search',
        async (page, e) => {
            await search(page, 'Samsung', e);

            const before = page.url();

            await page.goBack({
                waitUntil: 'domcontentloaded'
            });

            const after = page.url();

            note(e, { before, after });

            candidate(
                new URL(after).pathname !== '/',
                'Browser Back did not return to homepage',
                { before, after }
            );
        }
    );

    register('F01', 28, 'Rapid keyword replacement',
        async (page, e) => {
            await navigate(page, HOME);

            const input = searchField(page);
            await input.fill('Samsung');
            await page.waitForTimeout(100);
            await input.fill('iPhone');

            const actual = await input.inputValue();

            note(e, { expected: 'iPhone', actual });

            candidate(
                actual !== 'iPhone',
                'Input lost the latest keyword',
                { actual }
            );
        }
    );

    register('F01', 29, 'Two searches in succession',
        async (page, e) => {
            await search(page, 'Samsung', e);

            const second = await search(
                page,
                'Galaxy A07',
                e
            );

            note(e, { final: second.url });

            candidate(
                new URL(second.url).searchParams.get('q') !==
                'Galaxy A07',
                'Second search used stale query',
                { final: second.url }
            );
        }
    );

    register('F01', 30, 'Search by actual catalog product',
        async (page, e) => {
            await navigate(page, CATALOG);

            const products = await availableCards(page);
            const target = products.find(x =>
                /Galaxy A07/i.test(x.name)
            );

            if (!target) {
                unknown('Reference product Galaxy A07 unavailable');
            }

            const result = await search(
                page,
                'Galaxy A07',
                e
            );

            const found = await cards(page);

            note(e, {
                target,
                searchUrl: result.url,
                resultSlugs: found.map(x => x.slug)
            });

            candidate(
                !found.some(x => x.slug === target.slug),
                'Known catalog product missing from specific search',
                { target, found }
            );
        }
    );

    // ====================================================
    // F02 - 30 FILTER & SORT TESTS
    // ====================================================

    const ranges = [
        [0, 5000000],
        [3000000, 4000000],
        [5000000, 10000000],
        [7000000, 9000000],
        [10000000, 20000000],
        [15000000, 25000000],
        [25000000, 40000000],
        [40000000, 80000000]
    ] as const;

    ranges.forEach(([low, high], index) => {
        register('F02', index + 1,
            `Validate price range ${low}-${high}`,
            async (page, e) => {
                await openFilter(page, { low, high });
                await verifyPrices(page, e, low, high);
            }
        );
    });

    register('F02', 9, 'Ascending price correctness',
        async (page, e) => {
            await openFilter(page, { sort: 'ASC' });
            await verifySort(page, e, 'ASC');
        }
    );

    register('F02', 10, 'Descending price correctness',
        async (page, e) => {
            await openFilter(page, { sort: 'DESC' });
            await verifySort(page, e, 'DESC');
        }
    );

    register('F02', 11, 'Switch ascending to descending',
        async (page, e) => {
            await navigate(page, CATALOG);
            await waitForCards(page);

            await clickSort(page, 'ASC');
            await verifySort(page, e, 'ASC');

            await clickSort(page, 'DESC');
            await verifySort(page, e, 'DESC');
        }
    );

    register('F02', 12, 'Switch descending to ascending',
        async (page, e) => {
            await navigate(page, CATALOG);
            await waitForCards(page);

            await clickSort(page, 'DESC');
            await verifySort(page, e, 'DESC');

            await clickSort(page, 'ASC');
            await verifySort(page, e, 'ASC');
        }
    );

    const combinedPriceSort = [
        [5000000, 10000000, 'ASC'],
        [5000000, 10000000, 'DESC'],
        [10000000, 20000000, 'ASC'],
        [10000000, 20000000, 'DESC'],
        [15000000, 25000000, 'ASC'],
        [15000000, 25000000, 'DESC']
    ] as const;

    combinedPriceSort.forEach(
        ([low, high, direction], index) => {
            register('F02', index + 13,
                `Combined price and sorting ${direction}`,
                async (page, e) => {
                    await openFilter(page, {
                        low,
                        high,
                        sort: direction
                    });

                    await verifyPrices(page, e, low, high);
                    await verifySort(page, e, direction);
                }
            );
        }
    );

    [4, 6, 8, 12].forEach((ram, index) => {
        register('F02', index + 19,
            `Verify RAM ${ram}GB using product details`,
            async (page, e) => {
                await openFilter(page, { ram });

                await verifyFacet(
                    page,
                    e,
                    'RAM',
                    ram
                );
            }
        );
    });

    [64, 128, 256, 512].forEach((storage, index) => {
        register('F02', index + 23,
            `Verify storage ${storage}GB using product details`,
            async (page, e) => {
                await openFilter(page, { storage });

                await verifyFacet(
                    page,
                    e,
                    'STORAGE',
                    storage
                );
            }
        );
    });

    [128, 256].forEach((storage, index) => {
        register('F02', index + 27,
            `Combined RAM 8GB and storage ${storage}GB`,
            async (page, e) => {
                await openFilter(page, {
                    ram: 8,
                    storage
                });

                const params = new URL(page.url())
                    .searchParams;

                note(e, {
                    ram: params.get('spec_ram'),
                    storage: params.get('spec_bo_nho_trong')
                });

                // Both constraints must remain represented.
                candidate(
                    params.get('spec_ram') !== '8_gb' ||
                    params.get('spec_bo_nho_trong') !==
                    `${storage}_gb`,
                    'One combined filter parameter disappeared',
                    { url: page.url() }
                );

                await verifyFacet(page, e, 'RAM', 8);
                await verifyFacet(
                    page,
                    e,
                    'STORAGE',
                    storage
                );
            }
        );
    });

    register('F02', 29, 'Apply price filter using UI',
        async (page, e) => {
            await navigate(page, CATALOG);
            await waitForCards(page);

            const trigger = page.getByRole('button', {
                name: /^Giá(?:\s|$)/i
            }).first();

            if (!(await trigger.isVisible().catch(() => false))) {
                unknown('Price filter button unavailable');
            }

            await trigger.click();

            const dialog = page.locator(
                '[role="dialog"][data-side="bottom"]:visible'
            ).last();

            const inputs = dialog.locator(
                'input:not([type="range"]):visible'
            );

            if (await inputs.count() !== 2) {
                unknown('Price filter UI inputs not identified');
            }

            // Fill max before min to avoid invalid transient range.
            await inputs.nth(1).fill('10000000');
            await inputs.nth(1).press('Tab');

            const minInput = dialog.locator(
                'input:not([type="range"]):visible'
            ).first();

            await minInput.fill('5000000');
            await minInput.press('Tab');

            const apply = page.getByRole('button', {
                name: /^(Áp dụng|Xem kết quả)$/i
            }).first();

            if (await apply.isVisible().catch(() => false)) {
                await apply.click();
            } else {
                await page.keyboard.press('Escape');
            }

            await page.waitForTimeout(1100);

            note(e, {
                appliedUrl: page.url()
            });

            await verifyPrices(
                page,
                e,
                5000000,
                10000000
            );
        }
    );

    register('F02', 30, 'Filter survives page reload',
        async (page, e) => {
            await openFilter(page, {
                low: 5000000,
                high: 10000000,
                sort: 'ASC'
            });

            await verifyPrices(
                page, e, 5000000, 10000000
            );

            await page.reload({
                waitUntil: 'domcontentloaded'
            });

            await verifyPrices(
                page, e, 5000000, 10000000
            );

            await verifySort(page, e, 'ASC');
        }
    );

    // ====================================================
    // F03 - 30 COMPARISON TESTS
    // ====================================================

    [1, 2, 3].forEach((count, index) => {
        register('F03', index + 1,
            `Add ${count} products to comparison`,
            async (page, e) => {
                await addProducts(page, e, count);

                const items = await comparison(page);

                candidate(
                    items.length !== count ||
                    !uniqueComparison(items),
                    'Invalid comparison selection',
                    { count, items }
                );
            }
        );
    });

    [0, 1, 2].forEach((position, index) => {
        register('F03', index + 4,
            `Remove product at position ${position}`,
            async (page, e) => {
                const added = await addProducts(
                    page, e, 3
                );

                await removeProduct(
                    page, e, added[position]
                );

                const items = await comparison(page);

                candidate(
                    items.length !== 2,
                    'Incorrect remaining comparison count',
                    { items }
                );
            }
        );
    });

    [1, 2, 3].forEach((count, index) => {
        register('F03', index + 7,
            `Comparison survives reload with ${count} items`,
            async (page, e) => {
                await addProducts(page, e, count);

                const before = await comparison(page);

                await page.reload({
                    waitUntil: 'domcontentloaded'
                });

                const after = await comparison(page);

                note(e, { before, after });

                candidate(
                    compareIds(before) !== compareIds(after),
                    'Comparison changed after reload',
                    { before, after }
                );
            }
        );
    });

    const destinations = [
        HOME,
        IPHONE,
        'https://didongviet.vn/search?q=Samsung'
    ];

    destinations.forEach((destination, index) => {
        register('F03', index + 10,
            `Persist comparison across navigation ${index + 1}`,
            async (page, e) => {
                await addProducts(page, e, 2);

                const before = await comparison(page);

                await navigate(page, destination);

                const after = await comparison(page);

                note(e, {
                    destination,
                    before,
                    after
                });

                candidate(
                    compareIds(before) !== compareIds(after),
                    'Comparison lost items during navigation',
                    { destination, before, after }
                );
            }
        );
    });

    [1, 2, 3].forEach((count, index) => {
        register('F03', index + 13,
            `Stored prices match ${count} product cards`,
            async (page, e) => {
                const added = await addProducts(
                    page, e, count
                );

                const items = await comparison(page);
                const invalid = validateStoredPrices(
                    added,
                    items
                );

                note(e, { added, items, invalid });

                candidate(
                    invalid.length > 0,
                    'Stored comparison prices differ from cards',
                    { invalid }
                );
            }
        );
    });

    register('F03', 16, 'No duplicate product IDs',
        async (page, e) => {
            await addProducts(page, e, 3);

            const items = await comparison(page);

            note(e, { items });

            candidate(
                !uniqueComparison(items),
                'Duplicate comparison items detected',
                { items }
            );
        }
    );

    register('F03', 17, 'Cannot select a fourth product',
        async (page, e) => {
            await addProducts(page, e, 3);

            const selected = await comparison(page);
            const products = await availableCards(page);

            const fourth = products.find(x =>
                !selected.some(y => y.slug === x.slug)
            );

            if (!fourth) {
                unknown('Fourth product unavailable');
            }

            const control = await findCardButton(
                page,
                fourth.slug
            );

            if (!control) {
                unknown('Fourth comparison control unavailable');
            }

            try {
                await control.click({ timeout: 5000 });
            } catch {
                // An unavailable control may enforce the limit.
            }

            await page.waitForTimeout(600);

            const items = await comparison(page);

            note(e, { fourth, items });

            candidate(
                items.length > 3,
                'Comparison exceeded three-product limit',
                { items }
            );
        }
    );

    register('F03', 18, 'Replace a removed product',
        async (page, e) => {
            const added = await addProducts(
                page, e, 3
            );

            await removeProduct(
                page, e, added[1]
            );

            await addProduct(page, e);

            const items = await comparison(page);

            note(e, { items });

            candidate(
                items.length !== 3 ||
                !uniqueComparison(items),
                'Replacement created incorrect comparison state',
                { items }
            );
        }
    );

    register('F03', 19, 'Repeated selection toggle',
        async (page, e) => {
            const added = await addProducts(
                page, e, 1
            );

            const product = added[0];
            const observed: number[] = [1];

            for (const expected of [0, 1, 0, 1]) {
                const control = await findCardButton(
                    page,
                    product.slug
                );

                if (!control) {
                    unknown('Toggle comparison control unavailable');
                }

                await control.click();

                const current = await waitCompare(
                    page,
                    expected
                );

                observed.push(current.length);

                candidate(
                    current.length !== expected,
                    'Repeated toggle produced incorrect state',
                    { observed, expected }
                );
            }

            note(e, { observed });
        }
    );

    register('F03', 20, 'Remove all selected products',
        async (page, e) => {
            const added = await addProducts(
                page, e, 3
            );

            for (const product of [...added].reverse()) {
                await removeProduct(page, e, product);
            }

            const items = await comparison(page);

            candidate(
                items.length !== 0,
                'Comparison not empty after removing all',
                { items }
            );
        }
    );

    [2, 3].forEach((count, index) => {
        register('F03', index + 21,
            `Open comparison table with ${count} products`,
            async (page, e) => {
                await addProducts(page, e, count);

                await openComparisonTable(page);

                const body = await page.locator('body').innerText();

                const items = await comparison(page);
                const visible = items.filter(x =>
                    body.includes(x.name)
                );

                note(e, {
                    url: page.url(),
                    items,
                    visible: visible.map(x => x.name)
                });

                candidate(
                    visible.length === 0,
                    'Selected product names absent from comparison UI',
                    { items, url: page.url() }
                );
            }
        );
    });

    register('F03', 23, 'Comparison table product identity',
        async (page, e) => {
            await addProducts(page, e, 2);
            const items = await comparison(page);

            await openComparisonTable(page);

            const text = normalize(
                await page.locator('body').innerText()
            ).toLowerCase();

            const missing = items.filter(x =>
                !text.includes(x.name.toLowerCase())
            );

            note(e, { items, missing });

            candidate(
                missing.length > 0,
                'Selected product missing from comparison view',
                { missing }
            );
        }
    );

    register('F03', 24, 'Selected product IDs are populated',
        async (page, e) => {
            await addProducts(page, e, 3);
            const items = await comparison(page);

            const invalid = items.filter(
                x => !x.productId || !x.slug || !x.name
            );

            note(e, { items, invalid });

            candidate(
                invalid.length > 0,
                'Comparison stores incomplete product data',
                { invalid }
            );
        }
    );

    register('F03', 25, 'Comparison data remains valid JSON',
        async (page, e) => {
            await addProducts(page, e, 2);

            const raw = await page.evaluate(() =>
                localStorage.getItem('ddv-compare')
            );

            if (!raw) {
                unknown('Comparison storage was not created');
            }

            let parsed: any;

            try {
                parsed = JSON.parse(raw);
            } catch {
                throw new SuspectedDefect(
                    'Malformed comparison JSON',
                    { raw }
                );
            }

            const items = parsed?.state?.items;

            note(e, { items });

            candidate(
                !Array.isArray(items) || items.length !== 2,
                'Unexpected comparison storage structure',
                { parsed }
            );
        }
    );

    register('F03', 26, 'Removed item stays removed after F5',
        async (page, e) => {
            const added = await addProducts(
                page, e, 3
            );

            await removeProduct(
                page,
                e,
                added[1]
            );

            const before = await comparison(page);

            await page.reload({
                waitUntil: 'domcontentloaded'
            });

            const after = await comparison(page);

            note(e, { before, after });

            candidate(
                compareIds(before) !== compareIds(after),
                'Removed item reappeared after reload',
                { before, after }
            );
        }
    );

    register('F03', 27, 'Add product across catalog and search',
        async (page, e) => {
            await addProducts(page, e, 1);

            await navigate(
                page,
                'https://didongviet.vn/search?q=Samsung'
            );

            await addProduct(page, e);

            const items = await comparison(page);

            candidate(
                items.length !== 2 ||
                !uniqueComparison(items),
                'Cross-page comparison failed',
                { items }
            );
        }
    );

    register('F03', 28, 'Add product after price sorting',
        async (page, e) => {
            await openFilter(page, { sort: 'ASC' });

            await verifySort(page, e, 'ASC');
            await addProduct(page, e);

            const items = await comparison(page);

            candidate(
                items.length !== 1,
                'Comparison failed after sorting',
                { items }
            );
        }
    );

    register('F03', 29, 'Add product after filtering price',
        async (page, e) => {
            await openFilter(page, {
                low: 5000000,
                high: 10000000
            });

            await verifyPrices(
                page,
                e,
                5000000,
                10000000
            );

            await addProduct(page, e);

            const items = await comparison(page);

            candidate(
                items.length !== 1,
                'Comparison failed on filtered product list',
                { items }
            );
        }
    );

    register('F03', 30, 'Comparison data shared across tabs',
        async (page, e) => {
            await addProducts(page, e, 2);

            const before = await comparison(page);

            const secondTab = await page.context().newPage();

            try {
                await navigate(secondTab, CATALOG);

                const after = await comparison(secondTab);

                note(e, { before, after });

                candidate(
                    compareIds(before) !== compareIds(after),
                    'Same-browser tabs have different stored comparison',
                    { before, after }
                );
            } finally {
                await secondTab.close().catch(() => {});
            }
        }
    );
});